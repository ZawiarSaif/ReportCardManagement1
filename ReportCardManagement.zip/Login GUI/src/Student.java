class Student extends Module {
    private String name;
    private int group;
    private String module;
    private int[] scores;

    public void setName(String name) {
        this.name = name;
    }

    public void setGroup(int group) {
        this.group = group;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public void setScores(int[] scores) {
        this.scores = scores;
    }

    public String getName() {
        return name;
    }

    public int getGroup() {
        return group;
    }

    public String getModule() {
        return module;
    }

    public int[] getScores() {
        return scores;
    }
}
