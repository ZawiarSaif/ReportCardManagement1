import java.util.Scanner;


public class ReportCardSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println(" REPORT CARD ");


        // Prompt user for group number
        System.out.print("Enter your group number (1-3): ");
        int group = scanner.nextInt();

        // Create a new student
        Student student = new Student();
        student.setGroup(group);
        student.setModule(Module.getModuleByGroup(group));

        // Prompt user for student details
        System.out.print("Enter student name: ");

        // Consume the newline character
        scanner.nextLine();
        String name = scanner.nextLine();
        student.setName(name);

        // Prompt user for scores
        int[] scores = new int[3];
        for (int i = 0; i < scores.length; i++) {
            System.out.print("Enter score for Module " + (i + 1) + ": ");
            scores[i] = scanner.nextInt();
        }
        student.setScores(scores);

        // Display the report card
        System.out.println(" REPORT CARD ");
        System.out.println("Name: " + student.getName());
        System.out.println("Group: " + student.getGroup());
        System.out.println("Module: " + student.getModule());
        System.out.println("Scores: ");
        for (int i = 0; i < scores.length; i++) {
            System.out.println("Module " + (i + 1) + ": " + scores[i]);
        }
        System.out.println(" ");

        // Calculate and display the average score
        int sum = 0;
        for (int score : scores) {
            sum += score;
        }
        double average = sum / (double) scores.length;
        System.out.println("Average score: " + average);

        scanner.close();

        if (average >= 40) {
            System.out.println(" CONGRATULATIONS! You Passed ");
        } else if (average < 40) {
            System.out.println(" Sorry you Failed. You need to Re-sit ");
        }


    }
}