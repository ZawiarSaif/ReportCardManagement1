class Module {
    // Creating Objects, Assigning Groups to students
    public static String getModuleByGroup(int group) {
        switch (group) {
            case 1:
                return "Engineering";
            case 2:
                return "Biology";
            case 3:
                return "Business";
            default:
                return "Unknown";
        }
    }
}